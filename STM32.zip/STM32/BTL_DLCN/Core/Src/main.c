#include "main.h"
#include "lcd.h"
#include "stdio.h"
#include "string.h"
#include <stdbool.h>
#include <math.h>
#include <stdlib.h>
/* ================== CONFIG ================== */
#define STABLE_SAMPLES 1250
//#define CALIB_WEIGHT   439.0f
#define LOCK_THRESHOLD 0.3f
#define ZERO_BAND      0.70f
#define SMOOTH_ALPHA   0.08f

/* ================== GLOBAL ================== */
ADC_HandleTypeDef hadc1;
I2C_HandleTypeDef hi2c1;
UART_HandleTypeDef huart1;
DMA_HandleTypeDef hdma_usart1_tx;
DMA_HandleTypeDef hdma_usart1_rx;

float x0 = 0.0f;
float x1 = 0.0f;
float calib_weight_val = 0.0f;
float mass_filtered = 0.0f;
float mass_display = 0.0f;
float tara_offset = 0.0f;
char rx_buffer[32];              
int rx_idx = 0;
bool is_calibrated = false;

char pc_buf[128];

volatile uint8_t uart_busy = 0;

/* ================== PROTOTYPES ================== */
void SystemClock_Config(void);

static void MX_GPIO_Init(void);
static void MX_DMA_Init(void);
static void MX_I2C1_Init(void);
static void MX_ADC1_Init(void);
static void MX_USART1_UART_Init(void);

float Read_ADC_Stable(void);
void Execute_Calib_Sequence(void);

/* ================== ADC READ ================== */
float Read_ADC_Stable(void)
{
    uint64_t sum = 0;

    for (int i = 0; i < STABLE_SAMPLES; i++)
    {
        HAL_ADC_Start(&hadc1);

        if (HAL_ADC_PollForConversion(&hadc1, 1) == HAL_OK)
        {
            sum += HAL_ADC_GetValue(&hadc1);
        }

        HAL_ADC_Stop(&hadc1);
    }

    return (float)sum / STABLE_SAMPLES;
}

/* ================== CALIB ================== */
void Execute_Calib_Sequence(void)
{
    LCD_Clear();
    LCD_Send_String("STEP1 EMPTY");

    HAL_UART_Transmit(&huart1,
                      (uint8_t*)"CALIB STEP1\r\n",
                      14,
                      100);

    HAL_Delay(3000);

    x0 = Read_ADC_Stable() * 3.3f / 4095.0f;

    LCD_Clear();
    LCD_Send_String("PUT 92g");

    HAL_UART_Transmit(&huart1,
                      (uint8_t*)"PUT 92G\r\n",
                      10,
                      100);

    HAL_Delay(6000);

    x1 = Read_ADC_Stable() * 3.3f / 4095.0f;

    is_calibrated = true;

    tara_offset = 0;
    mass_display = 0;
    mass_filtered = 0;

    LCD_Clear();
    LCD_Send_String("CALIB DONE");

    HAL_UART_Transmit(&huart1,
                      (uint8_t*)"CALIB DONE\r\n",
                      13,
                      100);

    HAL_Delay(1000);
}

/* ================== MAIN ================== */
int main(void)
{
    HAL_Init();

    SystemClock_Config();

    MX_GPIO_Init();
    MX_DMA_Init();
    MX_I2C1_Init();
    MX_ADC1_Init();
    MX_USART1_UART_Init();

    LCD_Init(&hi2c1);

    LCD_Clear();
    LCD_Send_String("LOADCELL");

    HAL_Delay(1000);

    while (1)
    {
        if (__HAL_UART_GET_FLAG(&huart1, UART_FLAG_RXNE)) {
					uint8_t rx_data = (uint8_t)(huart1.Instance->DR & 0x00FF);

					if (rx_data == 'C') { 
							Execute_Calib_Sequence(); // Ch? ch?y Calib khi nh?n ch? C
					} 
					else if (rx_data == 'T') {
							tara_offset = mass_filtered; // Tare khi nh?n ch? T
					}
					else if (rx_data == 'S') { 
							rx_idx = 0; // Nh?n ch? S th� chu?n b? nh?n s? m?i
					}
					else if ((rx_data >= '0' && rx_data <= '9') || rx_data == '.') {
							if (rx_idx < 31) rx_buffer[rx_idx++] = (char)rx_data;
					}
					else if (rx_data == '\n' || rx_data == '\r') {
							if (rx_idx > 0) {
									rx_buffer[rx_idx] = '\0';
									calib_weight_val = atof(rx_buffer); // C?p nh?t s? m?i v�o bi?n
									rx_idx = 0;
							}
					}
            
            /* TARE gi? nguy�n */
            if (rx_data == 'T') {
                tara_offset = mass_filtered;
                LCD_Clear();
                LCD_Send_String("TARE OK");
                HAL_Delay(500);
            }
        }

        /* ================= ADC ================= */
        float adc_avg =
            Read_ADC_Stable();

        float v_now =
            adc_avg * 3.3f / 4095.0f;

        /* ================= MASS ================= */
        if (is_calibrated)
        {
            float raw_mass =
                (calib_weight_val *
                (v_now - x0) /
                (x1 - x0));

            mass_filtered =
                (raw_mass * SMOOTH_ALPHA) +
                (mass_filtered *
                (1.0f - SMOOTH_ALPHA));

            float current_net =
                mass_filtered -
                tara_offset;

            if (fabsf(current_net) < ZERO_BAND)
            {
                current_net = 0.0f;
            }

            if (fabsf(current_net -
                mass_display)
                > LOCK_THRESHOLD)
            {
                mass_display =
                    current_net;
            }
        }

        /* ================= LCD ================= */
        char line1[20];
        char line2[20];

        sprintf(line1,
				"Volt:%0.4f",
                v_now);

        sprintf(line2,
                "Weight:%0.2f g",
                mass_display);

        LCD_Set_Cursor(0,0);
        LCD_Send_String(line1);

        LCD_Set_Cursor(1,0);
        LCD_Send_String(line2);

        /* ================= UART TX ================= */
        if (!uart_busy)
        {
            int len =
                sprintf(pc_buf,
                        "W:%.2f|V:%.4f|ADC:%d\r\n",
                        mass_display,
                        v_now,
                        (int)adc_avg);

            uart_busy = 1;

            HAL_UART_Transmit_DMA(&huart1,
                                  (uint8_t*)pc_buf,
                                  len);
        }

        /* ================= BUTTON ================= */
        if (HAL_GPIO_ReadPin(GPIOB,
                             GPIO_PIN_14)
                             == GPIO_PIN_RESET)
        {
            Execute_Calib_Sequence();
        }

        if (HAL_GPIO_ReadPin(GPIOB,
                             GPIO_PIN_15)
                             == GPIO_PIN_RESET)
        {
            tara_offset =
                mass_filtered;
        }

        HAL_Delay(20);
    }
}

/* ================== CLOCK ================== */
void SystemClock_Config(void)
{
    RCC_OscInitTypeDef RCC_OscInitStruct = {0};
    RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

    RCC_OscInitStruct.OscillatorType =
        RCC_OSCILLATORTYPE_HSE;

    RCC_OscInitStruct.HSEState =
        RCC_HSE_ON;

    RCC_OscInitStruct.PLL.PLLState =
        RCC_PLL_ON;

    RCC_OscInitStruct.PLL.PLLSource =
        RCC_PLLSOURCE_HSE;

    RCC_OscInitStruct.PLL.PLLMUL =
        RCC_PLL_MUL9;

    HAL_RCC_OscConfig(&RCC_OscInitStruct);

    RCC_ClkInitStruct.ClockType =
        RCC_CLOCKTYPE_HCLK |
        RCC_CLOCKTYPE_SYSCLK |
        RCC_CLOCKTYPE_PCLK1 |
        RCC_CLOCKTYPE_PCLK2;

    RCC_ClkInitStruct.SYSCLKSource =
        RCC_SYSCLKSOURCE_PLLCLK;

    HAL_RCC_ClockConfig(
        &RCC_ClkInitStruct,
        FLASH_LATENCY_2);
}

/* ================== ADC ================== */
static void MX_ADC1_Init(void)
{
    ADC_ChannelConfTypeDef sConfig = {0};

    hadc1.Instance = ADC1;

    hadc1.Init.ScanConvMode =
        ADC_SCAN_DISABLE;

    hadc1.Init.ContinuousConvMode =
        DISABLE;

    hadc1.Init.ExternalTrigConv =
        ADC_SOFTWARE_START;

    hadc1.Init.DataAlign =
        ADC_DATAALIGN_RIGHT;

    hadc1.Init.NbrOfConversion = 1;

    HAL_ADC_Init(&hadc1);

    sConfig.Channel = ADC_CHANNEL_0;
    sConfig.Rank = ADC_REGULAR_RANK_1;

    sConfig.SamplingTime =
        ADC_SAMPLETIME_239CYCLES_5;

    HAL_ADC_ConfigChannel(
        &hadc1,
        &sConfig);
}

/* ================== DMA ================== */
static void MX_DMA_Init(void)
{
    __HAL_RCC_DMA1_CLK_ENABLE();

    hdma_usart1_tx.Instance =
        DMA1_Channel4;

    hdma_usart1_tx.Init.Direction =
        DMA_MEMORY_TO_PERIPH;

    hdma_usart1_tx.Init.PeriphInc =
        DMA_PINC_DISABLE;

    hdma_usart1_tx.Init.MemInc =
        DMA_MINC_ENABLE;

    hdma_usart1_tx.Init.PeriphDataAlignment =
        DMA_PDATAALIGN_BYTE;

    hdma_usart1_tx.Init.MemDataAlignment =
        DMA_MDATAALIGN_BYTE;

    hdma_usart1_tx.Init.Mode =
        DMA_NORMAL;

    hdma_usart1_tx.Init.Priority =
        DMA_PRIORITY_LOW;

    HAL_DMA_Init(&hdma_usart1_tx);

    __HAL_LINKDMA(&huart1,
                  hdmatx,
                  hdma_usart1_tx);

    HAL_NVIC_SetPriority(
        DMA1_Channel4_IRQn,
        0,
        0);

    HAL_NVIC_EnableIRQ(
        DMA1_Channel4_IRQn);
}

/* ================== I2C ================== */
static void MX_I2C1_Init(void)
{
    hi2c1.Instance = I2C1;

    hi2c1.Init.ClockSpeed = 100000;
    hi2c1.Init.DutyCycle = I2C_DUTYCYCLE_2;
    hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;

    HAL_I2C_Init(&hi2c1);
}

/* ================== UART ================== */
static void MX_USART1_UART_Init(void)
{
    huart1.Instance = USART1;

    huart1.Init.BaudRate = 115200;

    huart1.Init.WordLength =
        UART_WORDLENGTH_8B;

    huart1.Init.StopBits =
        UART_STOPBITS_1;

    huart1.Init.Parity =
        UART_PARITY_NONE;

    huart1.Init.Mode =
        UART_MODE_TX_RX;

    HAL_UART_Init(&huart1);
}

/* ================== GPIO ================== */
static void MX_GPIO_Init(void)
{
    __HAL_RCC_GPIOB_CLK_ENABLE();

    GPIO_InitTypeDef GPIO_InitStruct = {0};

    GPIO_InitStruct.Pin =
        GPIO_PIN_14 |
        GPIO_PIN_15;

    GPIO_InitStruct.Mode =
        GPIO_MODE_INPUT;

    GPIO_InitStruct.Pull =
        GPIO_PULLUP;

    HAL_GPIO_Init(GPIOB,
                  &GPIO_InitStruct);
}

/* ================== UART TX DONE ================== */
void HAL_UART_TxCpltCallback(
    UART_HandleTypeDef *huart)
{
    if (huart->Instance == USART1)
    {
        uart_busy = 0;
    }
}

/* ================== ERROR ================== */
void Error_Handler(void)
{
    __disable_irq();

    while (1)
    {

    }
}