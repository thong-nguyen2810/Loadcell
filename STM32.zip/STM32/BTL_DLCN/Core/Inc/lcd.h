#ifndef LCD_H
#define LCD_H

#include "stm32f1xx_hal.h"

void LCD_Init(I2C_HandleTypeDef *hi2c);
void LCD_Send_Cmd(char cmd);
void LCD_Send_Data(char data);
void LCD_Send_String(char *str);
void LCD_Set_Cursor(int row, int col);
void LCD_Clear(void);

#endif

