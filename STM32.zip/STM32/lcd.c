#include "lcd.h"

extern I2C_HandleTypeDef hi2c1;

#define SLAVE_ADDRESS_LCD 0x4E   // 0x27 << 1

void LCD_Send_Cmd(char cmd)
{
    char data_u, data_l;
    uint8_t data_t[4];

    data_u = (cmd & 0xF0);
    data_l = ((cmd << 4) & 0xF0);

    data_t[0] = data_u | 0x0C;
    data_t[1] = data_u | 0x08;
    data_t[2] = data_l | 0x0C;
    data_t[3] = data_l | 0x08;

    HAL_I2C_Master_Transmit(&hi2c1, SLAVE_ADDRESS_LCD, data_t, 4, 100);
}

void LCD_Send_Data(char data)
{
    char data_u, data_l;
    uint8_t data_t[4];

    data_u = (data & 0xF0);
    data_l = ((data << 4) & 0xF0);

    data_t[0] = data_u | 0x0D;
    data_t[1] = data_u | 0x09;
    data_t[2] = data_l | 0x0D;
    data_t[3] = data_l | 0x09;

    HAL_I2C_Master_Transmit(&hi2c1, SLAVE_ADDRESS_LCD, data_t, 4, 100);
}

void LCD_Clear(void)
{
    LCD_Send_Cmd(0x01);
    HAL_Delay(2);
}

void LCD_Set_Cursor(int row, int col)
{
    int pos;

    if (row == 0) pos = 0x80 + col;
    else pos = 0xC0 + col;

    LCD_Send_Cmd(pos);
}

void LCD_Init(I2C_HandleTypeDef *hi2c)
{
    HAL_Delay(50);

    LCD_Send_Cmd(0x30);
    HAL_Delay(5);
    LCD_Send_Cmd(0x30);
    HAL_Delay(1);
    LCD_Send_Cmd(0x30);
    HAL_Delay(10);

    LCD_Send_Cmd(0x20);
    HAL_Delay(10);

    LCD_Send_Cmd(0x28);
    LCD_Send_Cmd(0x08);
    LCD_Send_Cmd(0x01);
    HAL_Delay(2);
    LCD_Send_Cmd(0x06);
    LCD_Send_Cmd(0x0C);
}

void LCD_Send_String(char *str)
{
    while (*str) LCD_Send_Data(*str++);
}
